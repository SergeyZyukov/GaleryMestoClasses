(function () {
  /* eslint-disable no-undef */  
  const placesList = document.querySelector('.places-list');
  const popupPersonal = document.querySelector('.popup__personal');
  const popupPlace = document.querySelector('.popup__place');
  const popupScr = document.querySelector('.popup__scrplacecard');

     
  const api = new Api({
    baseUrl: 'http://95.216.175.5/cohort7',
    headers: {
      authorization: 'd8903c6e-110d-41c9-8159-ce53bb9b7240',
      'Content-Type': 'application/json'
    }
  }); 

  const formValidatorForUser = (...args) => new FormValidator(...args);
  const formValidator = new FormValidator();
  const createCard = (...args) => new Card(...args);    
  const fotoSet = new PlacesList(placesList, createCard);
  const firstFotoSet = new PlacesList(placesList, createCard, api);

  firstFotoSet.firstSetCards();
    
  const userInfo = new UserInfo({}, api);

  userInfo.updateUserInfo();
 
  const popupUserProfile = new UserProfilePopup(popupPersonal, formValidatorForUser, userInfo);
  const popupNewPlace = new NewPlacePopup(popupPlace);
  const popupScrImage = new ScrImagePopup(popupScr); 


  /* Обработчик submit на формах */
  function submitHandlerForm(event) {
    event.preventDefault();
    const childButton = event.target.querySelector('.button');
    const parent = event.target.closest('.popup');
    const forma = event.target.closest('.popup__form');   
    const name = event.target.elements.name.value;
    const link = event.target.elements.linkabout.value;
    const userData = {
      name,
      link
    };
  
    if (forma === document.newPlace) {
      fotoSet.addCard(userData);
      popupNewPlace.close(parent);
      parent.classList.remove('popup_is-opened');
      formValidator.setSubmitButtonState(childButton, false);
      forma.reset();
    }
    if (forma === document.personal) {
      userInfo.setUserInfo(userData);
      userInfo.updateUserInfo(userData);    
      popupUserProfile.close(parent);
      formValidator.setSubmitButtonState(childButton, false);
    }  
  } 

  document.forms.personal.addEventListener('submit', submitHandlerForm);
  document.forms.newPlace.addEventListener('submit', submitHandlerForm);
}());

/**
* Здравствуйте.
* Надо исправить: Название файлов должна быть идентично названию класса Например если класс назвается FormValidator, то файл должен называться FormValidator
(Здравствуйте! Было замечание по предыдущему спринту 8 - " - для разделения слов в названиях файлов следует использовать знак "-", а не писать слитно, например places-list.js". Поэтому этот момент неопределен.)
*
 *  Надо исправить: Для начала вам необходимо создать класс API в котором каждый метод
 * Все запросы должны быть методами этого класс. Если мы получаем список карточек, то в классе должен быть метод getInitialCards
 * Если профиль пользователя то getUserInfo и так далее
 *  *
  * Самый правильный способ, как пример указан в брифе
  // url лучше передавать при инициализации класса в конструктор
  fetch(`url/cards`, {
    headers: {
   // ключ который надо передавать в параметрах
   authorization: authorization
     }
     })
   .then(res => {
    if (res.ok) {
       return res.json();
     }
     // если ошибка, переходим в catch
     return Promise.reject(`Ошибка: ${res.status
     }`);
     })
   .then((result) => {
     // обрабатываем результат
     // а точнее возвращает результат работы прямо в тот класс откуда вызывали
   })
   .catch((err) => {
   console.log(err); // выведем ошибку в консоль
   });

Хочу заметить что данные авторизации лучше передать при создании класса API в ввиде объекта

  * Вызывать же методы класса Api лучше из других классов
  *
 * Стоит отметить, что реализации в классе API быть не должно. Точнее прямого взаимодействия. Методы могут вызываться
 * из других классов и возвращать данные, а работа с этими данными должны быть непосредственно в классах создаваемых в 8 спринте
 *
 * работа принимается только при исправлении всех "Надо исправить"
 *
*/
