class PlacesList {
  constructor(container, createCard, apiInitialCards) {
    this.apiInitialCards = apiInitialCards;
    this.createCard = createCard;
    this.container = container; 
    this._render = this._render.bind(this); 
    this.initialCards = [];
  }  

  _arrayHandler(params) {
    this.params = params;
    this.params.forEach((item) => {
      const { name, link } = item; 
      const obj = {};
      obj.name = name;
      obj.link = link;
      this.initialCards.push(obj);       
    });    
    return this.initialCards;
  }
  
  addCard(userDataCards) {
    this.userDataCards = userDataCards;
    const card = this.createCard(this.userDataCards); 
    const cardElement = card.create();
    this.container.appendChild(cardElement);
    card.installHandlers(cardElement);    
  }
  
  _render(initialCards) {
    this.initialCards = this._arrayHandler(initialCards);
    this.initialCards.forEach((item) => {
      this.addCard(item);
    });  
  }

  firstSetCards() {
    this.apiInitialCards.getInitialCards()
      .then((res) => {
        if (res.ok) {
          return res.json();
        }         
        return Promise.reject(`Ошибка: ${res.status}`);
      })
      .then((data) => {    
        this._render(data);
      })
      .catch((err) => {
        console.log(err);
      });
  }
}