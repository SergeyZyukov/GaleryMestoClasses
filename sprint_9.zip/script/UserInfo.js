class UserInfo {
  constructor(userData, apiUserInfo) {
    this.apiUserInfo = apiUserInfo;
    this.userData = userData;
    this.changeData = true;
    this.userInfoName = document.querySelector('.user-info__name');
    this.userInfoJob = document.querySelector('.user-info__job');
    this.job = document.querySelector('.popup__input_type_about');
    this.name = document.querySelector('.popup__input_type_personal');
    this.userInfoFoto = document.querySelector('.user-info__photo');
  }  

  _dataRender(dataObj) {
    this.name.value = dataObj.name;
    this.job.value = dataObj.about;  
    this.avatar = dataObj.avatar;
    this.userInfoName.textContent = dataObj.name;
    this.userInfoJob.textContent = dataObj.about;
    this.userInfoFoto.setAttribute('style', `background-image:url(${this.avatar})`);
  }

  _compareOldandNewData() {
    this.apiUserInfo.getUserInfo()
      .then((res) => {
        if (res.ok) {
          return res.json();
        }         
        return Promise.reject(`Ошибка: ${res.status}`);
      })
      .then((data) => {
        this.changeData = !!(((data.name !== this.userData.name) || (data.about !== this.userData.link)));  
      })
      .catch((err) => {
        console.log(err);
      });
  }
  
  setUserInfo(userData) { 
    this._compareOldandNewData();    
    this.userData = userData;
    if (this.changeData) {
      this.apiUserInfo.setUserInfo(this.userData.name, this.userData.link)
        .then((res) => {
          if (res.ok) {
            return res.json();
          }         
          return Promise.reject(`Ошибка: ${res.status}`);
        })
        .then((data) => {
          this._dataRender(data);       
        })
        .catch((err) => {
          console.log(err);
        }); 
    }
    this.apiUserInfo.setUserInfo(this.userData.name, this.userData.link)
      .then((res) => {
        if (res.ok) {
          return res.json();
        }         
        return Promise.reject(`Ошибка: ${res.status}`);
      })
      .then((data) => {
        this._dataRender(data);       
      })
      .catch((err) => {
        console.log(err);
      }); 
  } 
  
  updateUserInfo() {
    this.apiUserInfo.getUserInfo()
      .then((res) => {
        if (res.ok) {
          return res.json();
        }  
        return Promise.reject(`Ошибка: ${res.status}`);
      })
      .then((data) => {
        this._dataRender(data);                            
      })
      .catch((err) => {
        console.log(err);
      });
  }
} 
